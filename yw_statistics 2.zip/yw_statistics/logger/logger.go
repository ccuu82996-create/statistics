package logger

import (
	"log"
	"os"
)

type Logger struct {
	fileLogger   *log.Logger
	stdoutLogger *log.Logger
}

// NewLogger 创建一个新的 Logger 实例
func NewLogger(filePath string) (*Logger, error) {
	// 打开或创建日志文件
	file, err := os.OpenFile(filePath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return nil, err
	}

	logger := &Logger{
		fileLogger:   log.New(file, "[FILE] ", log.Ldate|log.Ltime|log.Lshortfile),
		stdoutLogger: log.New(os.Stdout, "[STDOUT] ", log.Ldate|log.Ltime|log.Lshortfile),
	}

	return logger, nil
}

// InfoToFile 写日志到文件
func (l *Logger) InfoToFile(msg string) {
	l.fileLogger.Println(msg)
}

// InfoToConsole 写日志到控制台
func (l *Logger) InfoToConsole(msg string) {
	l.stdoutLogger.Println(msg)
}
