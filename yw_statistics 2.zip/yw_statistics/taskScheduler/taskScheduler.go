package taskScheduler

import (
	"time"
)

// Task 定义任务接口，每个任务都必须实现 Run()
type Task interface {
	Run()
}

// TaskScheduler 定时执行传入的任务
type TaskScheduler struct {
	interval time.Duration
	task     Task
	ticker   *time.Ticker
	quit     chan struct{}
}

// NewTaskScheduler 创建调度器
func NewTaskScheduler(interval time.Duration, task Task) *TaskScheduler {
	return &TaskScheduler{
		interval: interval,
		task:     task,
		quit:     make(chan struct{}),
	}
}

// Start 启动任务调度
func (ts *TaskScheduler) Start() {
	ts.ticker = time.NewTicker(ts.interval)
	go func() {
		for {
			select {
			case <-ts.ticker.C:
				ts.task.Run()
			case <-ts.quit:
				ts.ticker.Stop()
				return
			}
		}
	}()
}

// Stop 停止调度
func (ts *TaskScheduler) Stop() {
	close(ts.quit)
}
