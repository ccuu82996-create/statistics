package recordSrv

import (
	"context"
	"encoding/json"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
	"sync"
	"time"
	"yw_statistics/dataDB"
)

const (
	RedisAddr = "localhost:6379"
	RedisDB   = 0
)

type QueueMsg struct {
	Data     string    `json:"Data"`
	ClientIp string    `json:"client_ip"`
	Time     time.Time `json:"time"`
}

type RecordSrv struct {
	Rdb *dataDB.Redis
	Ctx context.Context
}

var instance *RecordSrv
var once sync.Once

// GetInstance 用来获取单例对象
func GetInstance() *RecordSrv {
	once.Do(func() {
		instance = new(RecordSrv)
		instance.Ctx = context.Background()
		instance.Rdb = dataDB.GetInstance()
	})
	return instance
}

func (r *RecordSrv) RecordData(c *gin.Context) {
	// 获取原始数据
	body, err := c.GetRawData()
	if err != nil {
		log.Printf("Error reading request body: %v", err)
		c.JSON(http.StatusBadRequest, gin.H{"error": "Failed to read request body"})
		return
	}
	queueData := QueueMsg{Data: string(body), ClientIp: c.ClientIP(), Time: time.Now()}
	jsonData, err := json.Marshal(queueData)
	if err != nil {
		log.Println("Error queueData 序列化失败:", err)
		return
	}
	// 将访问记录放入 Redis 队列
	queueKey := "access_queue"

	err = r.Rdb.LPush(queueKey, string(jsonData))
	if err != nil {
		log.Printf("Error adding visit to queue: %v", err)
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Error recording visit"})
		return
	}

	// 立即返回 OK
	c.JSON(http.StatusOK, gin.H{"message": "Visit recorded"})
}
