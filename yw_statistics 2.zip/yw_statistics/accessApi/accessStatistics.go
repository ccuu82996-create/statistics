package accessApi

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"log"
	"math"
	"net/http"
	"strings"
	"time"
	"yw_statistics/dataDB"
)

type AccessRequest struct {
	ChannelId int32  `json:"channel_id"`
	StartTime string `json:"start_time"`
	EndTime   string `json:"end_time"`
}

type StatisticsSrv struct {
	sqlYwDb *dataDB.Mysql
	sqlTjDb *dataDB.Mysql
	rds     *dataDB.Redis
}

func NewStatisticsSrv() *StatisticsSrv {
	srv := new(StatisticsSrv)
	sqlYwDb, err := dataDB.GetDBManager().Get("ywDB")
	if err != nil {
		log.Fatal(err)
	}
	sqlTjDb, err := dataDB.GetDBManager().Get("tjDB")
	if err != nil {
		log.Fatal(err)
	}
	srv.sqlYwDb = sqlYwDb
	srv.sqlTjDb = sqlTjDb
	srv.rds = dataDB.GetInstance()
	return srv
}
func (s *StatisticsSrv) GetStatisticsData(c *gin.Context) {
	var req AccessRequest
	loc, _ := time.LoadLocation("Asia/Shanghai")

	// 绑定 JSON 参数
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "请求参数不合法"})
		return
	}
	var startTime, endTime time.Time
	if strings.TrimSpace(req.StartTime) == "" {
		endTime = time.Now()
		startTime = time.Date(endTime.Year(), endTime.Month(), endTime.Day(), 0, 0, 0, 0, endTime.Location())
	}
	if strings.TrimSpace(req.EndTime) == "" {
		endTime = time.Now()
	}
	layout := "2006-01-02 15:04:05"
	if startTime.IsZero() {
		t, err := time.ParseInLocation(layout, req.StartTime, loc)
		if err != nil {
			msg := fmt.Sprintf("StartTime 解析失败:%v", err)
			c.JSON(http.StatusBadRequest, gin.H{"error": msg})
			return
		}
		startTime = t
	}
	if endTime.IsZero() {
		t, err := time.ParseInLocation(layout, req.EndTime, loc)
		if err != nil {
			msg := fmt.Sprintf("EndTime 解析失败:%v", err)
			c.JSON(http.StatusBadRequest, gin.H{"error": msg})
			return
		}
		endTime = t
	}
	type ChannelStat struct {
		ChannelID int32 `gorm:"column:channel_id" json:"channel_id"`
		AccessNum int32 `gorm:"column:access_num" json:"access_num"`
		IpNum     int32 `gorm:"column:ip_num" json:"ip_num"`
	}
	type DetailStat struct {
		ChannelID int32  `gorm:"column:channel_id" json:"channel_id"`
		AccessNum int32  `gorm:"column:access_num" json:"access_num"`
		IpNum     int32  `gorm:"column:ip_num" json:"ip_num"`
		Interval  string `gorm:"column:minute_group" json:"interval"`
	}
	var stats []ChannelStat
	var detailStats []DetailStat
	var regRate float64
	if req.ChannelId == 0 {
		s.sqlTjDb.DB.Debug().Model(&dataDB.AccessCollect{}).
			Select("channel_id, sum(access_num) as access_num, sum(ip_num) as ip_num").
			Where("create_time BETWEEN ? AND ?", startTime.Format("2006-01-02 15:04:05"), endTime.Format("2006-01-02 15:04:05")).
			Group("channel_id").
			Scan(&stats)
	} else {
		s.sqlTjDb.DB.Debug().Model(&dataDB.AccessCollect{}).
			Select("channel_id, sum(access_num) as access_num, sum(ip_num) as ip_num").
			Where("channel_id = ? AND create_time BETWEEN ? AND ?", req.ChannelId, startTime.Format("2006-01-02 15:04:05"), endTime.Format("2006-01-02 15:04:05")).
			Group("channel_id").
			Scan(&stats)
		s.sqlTjDb.DB.Debug().Model(&dataDB.AccessCollect{}).
			Select("channel_id, sum(access_num) as access_num, sum(ip_num) as ip_num,DATE_FORMAT(create_time, '%Y-%m-%d %H:%i') AS minute_group").
			Where("channel_id = ? AND create_time BETWEEN ? AND ?", req.ChannelId, startTime.Format("2006-01-02 15:04:05"), endTime.Format("2006-01-02 15:04:05")).
			Group("minute_group").
			Scan(&detailStats)
		utc8STime := startTime.In(loc)
		utc8ETime := endTime.In(loc)
		sqlStr := fmt.Sprintf("select count(1) from youtiao.yy_player where channel = %d and create_time BETWEEN %d and %d", req.ChannelId, utc8STime.Unix(), utc8ETime.Unix())
		var installNum int
		s.sqlYwDb.DB.Raw(sqlStr).Scan(&installNum)
		if len(stats) > 0 && stats[0].IpNum != 0 {
			regRate = float64(installNum) / float64(stats[0].IpNum) * 100
		}
	}
	c.JSON(http.StatusOK, gin.H{"message": "OK", "reg_rate": math.Round(regRate*100) / 100, "list": stats, "detail_list": detailStats})
}
