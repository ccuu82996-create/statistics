package dataDB

import (
	"time"
)

type AccessDetail struct {
	Id        int32  `gorm:"primaryKey;column:id"`
	ChannelId int32  `gorm:"column:channel_id;index"`
	IP        string `gorm:"column:ip;type:varchar(50);index"`
	Device    string `gorm:"column:device;type:varchar(300)"`
	Origin    string `gorm:"column:origin;type:varchar(300)"`
	RequestAt string `gorm:"column:req_time;type:datetime"`
}

func (a *AccessDetail) BuildName() string {
	t := time.Now()
	hourBlock := t.Hour() / 4 * 4
	timeKey := time.Date(t.Year(), t.Month(), t.Day(), hourBlock, 0, 0, 0, t.Location())

	return "accessdetail_" + timeKey.Format("2006010215")
}
func (a *AccessDetail) TableName() string {
	return a.BuildName()
}

type AccessCollect struct {
	Id        int32  `gorm:"primaryKey;column:id"`
	ChannelId int32  `gorm:"column:channel_id;index"`
	IpNum     int32  `gorm:"column:ip_num"`
	AccessNum int32  `gorm:"column:access_num"`
	CreateAt  string `gorm:"column:create_time;type:datetime"`
}

func (ac *AccessCollect) TableName() string {
	return "access_collect"
}
