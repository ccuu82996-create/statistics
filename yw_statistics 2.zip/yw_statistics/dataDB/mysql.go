package dataDB

import (
	"fmt"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"log"
	"reflect"
	"sync"
	"time"
)

const (
	MysqlMaxOpenConns = 50
	MysqlMaxIdleConns = 10
)

type Mysql struct {
	DB *gorm.DB
}

type DBManager struct {
	dbs map[string]*Mysql
	mu  sync.RWMutex
}

var mgrInstance *DBManager
var mgronce sync.Once

// 单例模式
func GetDBManager() *DBManager {
	mgronce.Do(func() {
		mgrInstance = &DBManager{
			dbs: make(map[string]*Mysql),
		}
	})
	return mgrInstance
}

// 注册新的数据库连接（可重复调用）
func (m *DBManager) Register(name, dsn string) error {
	m.mu.Lock()
	defer m.mu.Unlock()

	if _, exists := m.dbs[name]; exists {
		return nil // 已注册
	}

	db := new(Mysql)
	db.Init(dsn)

	m.dbs[name] = db
	log.Printf("MySQL [%s] 注册成功", name)
	return nil
}

// 获取数据库连接
func (m *DBManager) Get(name string) (*Mysql, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	db, exists := m.dbs[name]
	if !exists {
		return nil, fmt.Errorf("未找到数据库实例: %s", name)
	}
	return db, nil
}

func (sql *Mysql) Init(dsn string) {
	//dsn := fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=True&loc=Local", MysqlUser, MysqlPassWord, MysqlAddr, MysqlDB)
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		panic("连接数据库失败: " + err.Error())
	}
	sql.DB = db
	sqlDB, err := sql.DB.DB()
	if err != nil {
		panic(err)
	}

	sqlDB.SetMaxOpenConns(MysqlMaxOpenConns)
	sqlDB.SetMaxIdleConns(MysqlMaxIdleConns)
	sqlDB.SetConnMaxLifetime(1 * time.Hour)
	sqlDB.SetConnMaxIdleTime(10 * time.Minute)
}

func (sql *Mysql) Insert(tableName string, data interface{}) error {
	rv := reflect.ValueOf(data)
	if rv.Kind() != reflect.Ptr || rv.Elem().Kind() != reflect.Struct {
		return fmt.Errorf("data 必须是结构体指针")
	}
	err := sql.DB.Table(tableName).AutoMigrate(data)
	if err != nil {
		return err
	}
	sql.DB.Table(tableName).Create(data)
	return nil
}
