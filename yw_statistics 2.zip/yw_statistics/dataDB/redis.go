package dataDB

import (
	"github.com/go-redis/redis"
	"sync"
	"time"
)

type Redis struct {
	Rdb    *redis.Client
	IsInit bool
}

var instance *Redis
var once sync.Once

func GetInstance() *Redis {
	once.Do(func() {
		instance = new(Redis)
		instance.IsInit = false
	})
	return instance
}

func (rds *Redis) Init(addr, password string, db int) {
	rds.Rdb = redis.NewClient(&redis.Options{
		Addr:         addr, // Redis 地址
		Password:     password,
		DB:           db, // 默认数据库
		PoolSize:     80, // 连接池大小，即允许同时打开的最大连接数
		MinIdleConns: 5,  // 最小空闲连接数，Redis 客户端将保持的空闲连接数
	})
	rds.IsInit = true
}
func (rds *Redis) LPush(key string, values string) error {
	return rds.Rdb.LPush(key, values).Err()
}

func (rds *Redis) BRPop(timeout time.Duration, keys string) ([]string, error) {
	return rds.Rdb.BRPop(timeout, keys).Result()
}

func (rds *Redis) HINCRBY(key string, field string, val int64) (int64, error) {
	return rds.Rdb.HIncrBy(key, field, val).Result()
}

func (rds *Redis) TTL(key string) (time.Duration, error) {
	return rds.Rdb.TTL(key).Result()
}

func (rds *Redis) Expire(key string, expiration int) (bool, error) {
	return rds.Rdb.Expire(key, time.Duration(expiration)*time.Second).Result()
}

func (rds *Redis) SAdd(key string, member string) (int64, error) {
	return rds.Rdb.SAdd(key, member).Result()
}
