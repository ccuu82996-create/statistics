package consume

import (
	"context"
	"fmt"
	"github.com/go-redis/redis"
	"log"
	"strings"
	"sync"
	"time"
	"yw_statistics/accessData"
	"yw_statistics/config"
	"yw_statistics/dataDB"
	"yw_statistics/logger"
)

const (
	MaxWorkers = 100
)

type Consume struct {
	rds            *dataDB.Redis
	ctx            context.Context
	consumerCancel context.CancelFunc
	wg             sync.WaitGroup
	workerPool     chan struct{}
	log            *logger.Logger
}

var instance *Consume
var once sync.Once

// GetInstance 用来获取单例对象
func GetInstance() *Consume {
	once.Do(func() {
		instance = new(Consume)
		instance.init()
	})
	return instance
}

func (consume *Consume) init() {
	consume.ctx = context.Background()
	consume.rds = dataDB.GetInstance()
	consume.workerPool = make(chan struct{}, MaxWorkers)
	nweLogger, err := logger.NewLogger("/var/log/access-server/access.log")
	if err != nil {
		fmt.Println("日志初始化失败:", err)
		return
	}
	consume.log = nweLogger
}

func (consume *Consume) StartConsumer() {
	var c context.Context
	c, consume.consumerCancel = context.WithCancel(consume.ctx)

	consume.wg.Add(1)
	go consume.consumeVisits(c)
}

func (consume *Consume) consumeVisits(ctx context.Context) {
	defer consume.wg.Done()

	queueKey := "access_queue"

	for {
		select {
		case <-ctx.Done():
			log.Println("Consumer stopped gracefully")
			return
		default:
			visitData, err := consume.rds.BRPop(5*time.Second, queueKey)
			if err != nil {
				if err == redis.Nil {
					continue // 没数据，继续等待
				}
				log.Printf("Error consuming visit: %v", err)
				continue
			}

			if len(visitData) < 2 {
				continue
			}

			visit := visitData[1]

			consume.workerPool <- struct{}{} // 阻塞直到有空余的 worker
			go consume.processData(visit)
		}
	}
}

func (consume *Consume) processData(data string) {
	defer func() {
		<-consume.workerPool // 释放 worker
	}()
	// 模拟入库操作
	log.Println("Processing access:", data)
	if config.NewEnvManager().GetBool("LogFile", false) {
		arr := strings.Split(config.NewEnvManager().GetString("LogChannel", ""), ",")
		for _, val := range arr {
			substr := ":" + val
			if strings.Contains(data, substr) {
				consume.log.InfoToFile("Processing access: " + data)
				break
			}
		}
	}
	access := accessData.NewAccess(data)
	if access == nil {
		log.Printf("accessData Error data : %s ,", data)
		return
	}
	access.DataToDB()
}
