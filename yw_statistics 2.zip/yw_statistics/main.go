package main

import (
	"fmt"
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	"log"
	"time"
	"yw_statistics/accessApi"
	"yw_statistics/accessData"
	"yw_statistics/config"
	"yw_statistics/consume"
	"yw_statistics/dataDB"
	"yw_statistics/recordSrv"
	"yw_statistics/taskScheduler"
)



var task *accessData.TenMinDBTask
var scheduler *taskScheduler.TaskScheduler

func execTask() {
	task = accessData.NewTenMinDBTask()
	scheduler = taskScheduler.NewTaskScheduler(10*60*time.Second, task)
	scheduler.Start()
}

func initDBConn() {
	env := config.NewEnvManager()
	ywDB := fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=True&loc=UTC",
		env.GetString("YwMysqlUser", YwMysqlUser),
		env.GetString("YwMysqlPassWord", YwMysqlPassWord),
		env.GetString("YwMysqlAddr", YwMysqlAddr),
		env.GetString("YwMysqlDB", YwMysqlDB))
	tjDB := fmt.Sprintf("%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=True&loc=UTC",
		env.GetString("TjMysqlUser", TjMysqlUser),
		env.GetString("TjMysqlPassWord", TjMysqlPassWord),
		env.GetString("TjMysqlAddr", TjMysqlAddr),
		env.GetString("TjMysqlDB", TjMysqlDB))
	sqlDbMgr := dataDB.GetDBManager()
	sqlDbMgr.Register("ywDB", ywDB)
	sqlDbMgr.Register("tjDB", tjDB)
	rds := dataDB.GetInstance()
	rds.Init(env.GetString("RedisAddr", RedisAddr),
		env.GetString("RedisPassWord", RedisPassWord),
		env.GetInt("RedisDB", RedisDB))
}

func main() {
	initDBConn()
	// 启动消费者处理 Redis 队列
	c := consume.GetInstance()
	c.StartConsumer()
	// 创建 Gin 路由
	r := gin.Default()
	srv := recordSrv.GetInstance()
	apiSrv := accessApi.NewStatisticsSrv()
	execTask()
	// 记录访问量接口
	r.Use(cors.New(cors.Config{
		AllowOrigins:     []string{"*"}, // 允许所有源访问
		AllowMethods:     []string{"POST", "GET"},
		AllowHeaders:     []string{"Origin", "Content-Type", "Authorization"},
		ExposeHeaders:    []string{"Content-Length"},
		AllowCredentials: true,           // 允许带上cookie
		MaxAge:           12 * time.Hour, // 预检请求有效期
	}))

	r.POST("/record", srv.RecordData)
	r.POST("/api/accessNum", apiSrv.GetStatisticsData)

	// 启动 Web 服务
	port := fmt.Sprintf(":%d", config.NewEnvManager().GetInt("ServerPort", 8008))
	err := r.Run(port)
	if err != nil {
		log.Fatalf("Could not start server: %v", err)
	}
}
