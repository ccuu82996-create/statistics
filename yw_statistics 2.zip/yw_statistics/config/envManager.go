package config

import (
	"os"
	"strconv"

	"github.com/joho/godotenv"
)

type EnvManager struct{}

func NewEnvManager() *EnvManager {
	// 自动加载 .env 文件，忽略不存在的情况
	_ = godotenv.Load()
	return &EnvManager{}
}

func (e *EnvManager) GetString(key string, defaultVal string) string {
	val := os.Getenv(key)
	if val == "" {
		return defaultVal
	}
	return val
}

func (e *EnvManager) GetInt(key string, defaultVal int) int {
	val := os.Getenv(key)
	if val == "" {
		return defaultVal
	}
	if i, err := strconv.Atoi(val); err == nil {
		return i
	}
	return defaultVal
}

func (e *EnvManager) GetBool(key string, defaultVal bool) bool {
	val := os.Getenv(key)
	if val == "" {
		return defaultVal
	}
	if b, err := strconv.ParseBool(val); err == nil {
		return b
	}
	return defaultVal
}
