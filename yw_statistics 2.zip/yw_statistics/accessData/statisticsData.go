package accessData

import (
	"fmt"
	"log"
	"time"
	"yw_statistics/dataDB"
	"yw_statistics/logger"
)

type TenMinDBTask struct {
	lastTime time.Time
	sqlDb    *dataDB.Mysql
	log      *logger.Logger
	rds      *dataDB.Redis
}

func NewTenMinDBTask() *TenMinDBTask {
	task := new(TenMinDBTask)
	sqlTjDb, err := dataDB.GetDBManager().Get("tjDB")
	if err != nil {
		log.Fatal(err)
	}
	task.rds = dataDB.GetInstance()
	task.sqlDb = sqlTjDb
	nweLogger, err := logger.NewLogger("/var/log/access-server/access.log")
	if err != nil {
		fmt.Println("日志初始化失败:", err)
	}
	task.log = nweLogger
	return task
}

func (t *TenMinDBTask) buildTableName(date time.Time) string {
	hourBlock := date.Hour() / 4 * 4
	timeKey := time.Date(date.Year(), date.Month(), date.Day(), hourBlock, 0, 0, 0, date.Location())
	return "accessdetail_" + timeKey.Format("2006010215")
}
func (t *TenMinDBTask) Run() {
	res := t.rds.Rdb.SetNX("TenMinAccessTask", 1, 8*60*time.Second)
	//log.Printf("Run Task res %v", res)
	if !res.Val() {
		return
	}
	now := time.Now()
	if t.lastTime.IsZero() {
		t.lastTime = now.Add(-10 * time.Minute)
	}
	type ChannelStat struct {
		ChannelID int32 `gorm:"column:channel_id"`
		Total     int32 `gorm:"column:total"`
		IpTotal   int32 `gorm:"column:ip_total"`
	}
	var stats []ChannelStat

	nHour := now.Hour() / 4 * 4
	lHour := t.lastTime.Hour() / 4 * 4
	//t.log.InfoToFile(fmt.Sprintf("TenMinDBTask Log nhour:%d lhour:%d", nHour, lHour))
	if nHour == lHour {
		t.sqlDb.DB.Model(&dataDB.AccessDetail{}).Table(t.buildTableName(now)).
			Select("channel_id, COUNT(1) as total, COUNT(DISTINCT ip) as ip_total").
			Where("req_time BETWEEN ? AND ?", t.lastTime.Format("2006-01-02 15:04:05"), now.Format("2006-01-02 15:04:05")).
			Group("channel_id").
			Scan(&stats)
	} else {
		var temp []ChannelStat
		t.sqlDb.DB.Model(&dataDB.AccessDetail{}).Table(t.buildTableName(now)).
			Select("channel_id, COUNT(1) as total, COUNT(DISTINCT ip) as ip_total").
			Where("req_time <= ?", now.Format("2006-01-02 15:04:05")).
			Group("channel_id").
			Scan(&stats)
		t.sqlDb.DB.Model(&dataDB.AccessDetail{}).Table(t.buildTableName(t.lastTime)).
			Select("channel_id, COUNT(1) as total, COUNT(DISTINCT ip) as ip_total").
			Where("req_time >= ?", t.lastTime.Format("2006-01-02 15:04:05")).
			Group("channel_id").
			Scan(&temp)
		stats = append(stats, temp...)
	}
	t.lastTime = now
	go func() {
		for _, val := range stats {
			collectData := &dataDB.AccessCollect{
				ChannelId: val.ChannelID,
				AccessNum: val.Total,
				IpNum:     val.IpTotal,
				CreateAt:  now.Format("2006-01-02 15:04:05"),
			}
			//t.log.InfoToFile(fmt.Sprintf("DetailDataToDB insert Res %v", res))
			err := t.sqlDb.Insert("access_collect", collectData)
			if err != nil {
				//log.Printf("DetailDataToDB Err %v", err)
				t.log.InfoToFile(fmt.Sprintf("DetailDataToDB Err %v", err))
			}
		}
	}()
}
