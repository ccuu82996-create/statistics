package accessData

import (
	"encoding/json"
	"fmt"
	"log"
	"math"
	"net"
	"strconv"
	"time"
	"yw_statistics/dataDB"
	"yw_statistics/recordSrv"
)

const (
	CurAccessNumKey    = "AccessNumDay:"
	CurIpNumKey        = "IpNumDay:"
	TenMinAccessNumKey = "AccessNum10Min"
	TenMinIpNumKey     = "IpNum10Min:"
)

func IpToInt(ip string) uint32 {
	parsedIP := net.ParseIP(ip)
	if parsedIP == nil {
		return 0
	}
	if parsedIP.To4() != nil {
		ipv4 := parsedIP.To4()
		return uint32(ipv4[0])<<24 | uint32(ipv4[1])<<16 | uint32(ipv4[2])<<8 | uint32(ipv4[3])
	}
	return 0
}

func SecondsToNextMidnight() int {
	// 获取当前时间
	now := time.Now()

	// 获取当天的0点
	tomorrow := time.Date(now.Year(), now.Month(), now.Day()+1, 0, 0, 0, 0, now.Location())

	// 计算当前时间到下一天0点的时间差
	duration := tomorrow.Sub(now)

	return int(duration.Seconds())
}

func StringIsIp(ipStr string) bool {
	ip := net.ParseIP(ipStr)
	if ip == nil {
		return false
	} else {
		return true
	}
}

type AccessInfo struct {
	ClientIp  string `json:"client_ip"`
	Device    string `json:"device"`
	Origin    string `json:"origin"`
	ChannelId int32  `json:"channel_id"`
	reqTime   time.Time
	rds       *dataDB.Redis
	sqlDb     *dataDB.Mysql
	longIP    uint32
}

func NewAccess(body string) *AccessInfo {
	access := new(AccessInfo)
	queueMsg := new(recordSrv.QueueMsg)
	if err := json.Unmarshal([]byte(body), queueMsg); err != nil {
		log.Printf("Error unmarshalling JSON: %v", err)
		return nil
	}
	if err := json.Unmarshal([]byte(queueMsg.Data), access); err != nil {
		log.Printf("Error unmarshalling JSON: %v", err)
		return nil
	}
	access.reqTime = queueMsg.Time
	if !StringIsIp(access.ClientIp) {
		access.ClientIp = queueMsg.ClientIp
	}
	access.rds = dataDB.GetInstance()
	sqlTjDb, err := dataDB.GetDBManager().Get("tjDB")
	if err != nil {
		log.Printf("Error GetDBManager Err: %v", err)
		return nil
	}
	access.sqlDb = sqlTjDb
	access.longIP = IpToInt(access.ClientIp)
	return access
}

func (access *AccessInfo) DataToDB() {
	access.dayDataToDB()
	//access.tenMinDataToDB()
	access.detailDataToDB()
}

func (access *AccessInfo) setExpire(expire int, keys ...string) {
	for _, key := range keys {
		exp, err := access.rds.TTL(key)
		if err != nil {
			log.Fatalf("Error getting TTL: %v", err)
		}
		if int(exp.Seconds()) == -1 {
			access.rds.Expire(key, expire)
		}
	}
}

func (access *AccessInfo) dayDataToDB() {
	now := time.Now()
	// 格式化成纯数字日期字符串
	timeStr := now.Format("20060102")
	accessKey := CurAccessNumKey + timeStr
	ipKey := fmt.Sprintf("%s%d:%s", CurIpNumKey, access.ChannelId, timeStr)
	_, err := access.rds.HINCRBY(accessKey, fmt.Sprintf("%d", access.ChannelId), 1)
	if err != nil {
		log.Printf("AccessNum ToDB Error,channel: %d, error: %v", access.ChannelId, err)
	}
	_, err = access.rds.SAdd(ipKey, access.ClientIp)
	if err != nil {
		log.Printf("IpNum ToDB Error,channel: %d,IP: %s error: %v", access.ChannelId, access.ClientIp, err)
		return
	}
	access.setExpire(SecondsToNextMidnight(), accessKey, ipKey)
}

func (access *AccessInfo) tenMinDataToDB() {
	now := time.Now()
	// 格式化成纯数字日期字符串
	timeStr := now.Format("150405")
	num, err := strconv.Atoi(timeStr)
	if err != nil {
		fmt.Println("Error converting string to number:", err)
		return
	}
	hmsTime := int(math.Floor(float64(num)/1000) * 1000)
	accessKey := fmt.Sprintf("%s%d", TenMinAccessNumKey, hmsTime)
	ipKey := fmt.Sprintf("%s%d:%d", TenMinIpNumKey, access.ChannelId, hmsTime)
	_, err = access.rds.HINCRBY(accessKey, fmt.Sprintf("%d", access.ChannelId), 1)
	if err != nil {
		log.Printf("TenMinData AccessNum ToDB Error,channel: %d, error: %v", access.ChannelId, err)
	}
	_, err = access.rds.SAdd(ipKey, access.ClientIp)
	if err != nil {
		log.Printf("TenMinData IpNum ToDB Error,channel: %d,IP: %s error: %v", access.ChannelId, access.ClientIp, err)
		return
	}
	access.setExpire(10*60, accessKey, ipKey)
}

func (access *AccessInfo) detailDataToDB() {
	detailData := &dataDB.AccessDetail{
		IP:        access.ClientIp,
		ChannelId: access.ChannelId,
		Device:    access.Device,
		Origin:    access.Origin,
		RequestAt: access.reqTime.Format("2006-01-02 15:04:05"),
	}
	err := access.sqlDb.Insert(detailData.BuildName(), detailData)
	if err != nil {
		log.Printf("DetailDataToDB Err %v", err)
	}
}
